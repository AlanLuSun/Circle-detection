Updated Ground Truth for
Industrial PCB Image Dataset (https://github.com/AlanLuSun/Circle-detection)

There are 100 text files in "Ground Truth" folder. In each file, the data format is shown as following: 

N 
x1 y1 rx1 ry1 phi1
x2 y2 rx2 ry2 phi2
...
xN yN rxN ryN phiN

N is the number of ellipses in image. xi and yi are the center coordinate. rxi and ryi are the semi-axes and phi is the orientation.
If you treat the PCB pads or holes as circles, the circle center can be got by averaging the rxi and ryi, namely (rxi + ryi)/2.

