addpath('./core/');

filename = '1.jpg'; 
filename2 = 'D:\Բ����Բ���Ӧ��\����-9178-5435\crop2.bmp';
% parameters
Tac = 165;
Tni = 0.5;

% read image
disp('read image------------------------------------------------');
I = imread(filename2);
figure;imshow(I);
% circle detection
disp('circle detetion-------------------------------------------');
[circles, ~,~] = circleDetectionByArcsupportLS(I, Tac, Tni);
% display
disp('show------------------------------------------------------');
circles
disp(['number of circles��',num2str(size(circles,1))]);
disp('draw circles----------------------------------------------');
dispImg = drawCircle(I,circles(:,1:2),circles(:,3));
figure;
imshow(dispImg);
