Specification (Changsheng Lu)
*It will show the results of circle detetion after running the demo.m. 
*running environment only supports the 64bit windows.

*In the core folder, we hided the processes of arc-support line segments extraction and paired line analysis for the reason of optimizing overall performance. But in the future, we will release all of source code.
