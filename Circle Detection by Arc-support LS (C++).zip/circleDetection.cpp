#include "circleDetection.h"
#include "miscellaneous.h"
#include "lsd.h"
#include <math.h>
#include <vector>
#include <queue>
#include <iostream>
#include <fstream>
using namespace std;

#include "highgui.h"
#include "cv.h"
#include "cxcore.h"
#include <opencv2/opencv.hpp>  //ͷ�ļ�
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>//��ͼ��Ҫ���������ͷ�ļ�
using namespace cv;


PairedSegmentList * pairedSegmentListInit( int length)
{
	if(length <= 0)
		return NULL;
		//error("paired segment length less equal than 0");
	PairedSegmentList * pairedSegList = (PairedSegmentList*)malloc(sizeof(PairedSegmentList));
	pairedSegList->length = length;
	pairedSegList->pairSeg = (PairedSegment*)malloc(sizeof(PairedSegment)*length);
	if(pairedSegList->pairSeg == NULL)
		error("pairedSegmentListInit,not enough memory");
	return pairedSegList;
}

void freePairedSegmentList( PairedSegmentList * list)
{
	if(list == NULL)
		return;
		//error("freePairedSegmentList,invalidate free");
	if(list->pairSeg != NULL)
		free(list->pairSeg);
	free(list);
	list = NULL;
}

//�����ݶȣ�����ģ�ͽǶȣ�ͬʱģֵ̫С�����ص�ֱ�����Ƶ�����ֵΪNOTDEF
//mod��anglesΪ�˴�ֵ���Ƕ���ָ��
void calculateGradient( double * img_in, unsigned int imgx, unsigned int imgy,image_double * mod, image_double * angles)
{
	if(img_in == NULL || imgx == 0 || imgy == 0)
		error("calculateGradient error!");
	(*mod) = new_image_double(imgx,imgy);
	(*angles) = new_image_double(imgx,imgy);
	double threshold = 2/sin(22.5/180*M_PI);
	unsigned int x,y,adr;
	double com1,com2;
	double gx,gy;
	double norm,norm_square;
	double sum = 0;

	//double max_grad = 0.0;
	//�߽��ʼΪNOTDEF
	for ( x = 0; x<imgx; x++) 
	{
		//(*angles)->data[x]=NOTDEF;
		(*angles)->data[(imgy-1)*imgx+x]=NOTDEF;
		//(*mod)->data[x]=NOTDEF;
		(*mod)->data[(imgy-1)*imgx+x]=NOTDEF;
	}
	for ( y = 0; y<imgy; y++) 
	{
		//(*angles)->data[y*imgx] = NOTDEF;
		(*angles)->data[y*imgx+imgx-1] = NOTDEF;
		//(*mod)->data[y*imgx] = NOTDEF;
		(*mod)->data[y*imgx+imgx-1] = NOTDEF;
	}
	 /* compute gradient on the remaining pixels */
	for(x=0;x<imgx-1;x++)
		for(y=0;y<imgy-1;y++)
		{
			adr = y*imgx+x;
		  /*
		     Norm 2 computation using 2x2 pixel window:
		       A B
		       C D
		     and
		       com1 = D-A,  com2 = B-C.
		     Then
		       gx = B+D - (A+C)   horizontal difference
		       gy = C+D - (A+B)   vertical difference
		     com1 and com2 are just to avoid 2 additions.
		   */
		  com1 = img_in[adr+imgx+1] - img_in[adr];
		  com2 = img_in[adr+1]   - img_in[adr+imgx];

		  gx = com1+com2; /* gradient x component */
		  gy = com1-com2; /* gradient y component */
		  norm_square = gx*gx+gy*gy;

		  norm = sqrt( norm_square / 4.0 ); /* gradient norm */

		  (*mod)->data[adr] = norm; /* store gradient norm */

		  if( norm <= threshold ) /* norm too small, gradient no defined */
		  {
		    (*angles)->data[adr] = NOTDEF; /* gradient angle not defined */
			(*mod)->data[adr] = NOTDEF;
		  }
		  else
		    {
		      /* gradient angle computation */
		      (*angles)->data[adr] = atan2(gx,-gy);
		    }
		}
}

//void calculateGradient2( double * img_in, unsigned int imgx, unsigned int imgy, image_double * mod, image_double * angles)
void calculateGradient_sobel( double * img_in, unsigned int imgx, unsigned int imgy, image_double * angles)
{
	if(img_in == NULL || imgx == 0 || imgy == 0)
		error("calculateGradient error!");
	image_double mod;
	(mod) = new_image_double(imgx,imgy);
	(*angles) = new_image_double(imgx,imgy);
	unsigned int x,y,adr;
	double com1,com2;
	double gx,gy;
	double norm,norm_square;
	double threshold;
	double sum = 0;
	double value;  
	//double max_grad = 0.0;
	//�߽��ʼΪNOTDEF
	for ( x = 0; x<imgx; x++) 
	{
		(*angles)->data[x]=NOTDEF;
		(*angles)->data[(imgy-1)*imgx+x]=NOTDEF;
		(mod)->data[x]=NOTDEF;
		(mod)->data[(imgy-1)*imgx+x]=NOTDEF;
	}
	for ( y = 0; y<imgy; y++) 
	{
		(*angles)->data[y*imgx] = NOTDEF;
		(*angles)->data[y*imgx+imgx-1] = NOTDEF;
		(mod)->data[y*imgx] = NOTDEF;
		(mod)->data[y*imgx+imgx-1] = NOTDEF;
	}
	 /* compute gradient on the remaining pixels */
	for(x=1;x<imgx-1;x++)
		for(y=1;y<imgy-1;y++)
		{
			adr = y*imgx+x;
		  /*
		     Norm 2 computation using 2x2 pixel window:
		       A B C
		       D E F
			   G H I
		     and
		       com1 = C-G,  com2 = I-A.
		     Then
		       gx = C+2F+I - (A+2D+G)=com1+com2+2(F-D)   horizontal difference
		       gy = G+2H+I - (A+2B+C)=-com1+com2+2(H-B)   vertical difference
		     com1 and com2 are just to avoid 2 additions.
		   */
		  com1 = img_in[adr-imgx+1] - img_in[adr+imgx-1];
		  com2 = img_in[adr+imgx+1] - img_in[adr-imgx-1];

		  gx = (com1+com2+2*(img_in[adr+1] - img_in[adr-1]))/(8.0*255); /* gradient x component */
		  gy = (-com1+com2+2*(img_in[adr+imgx] - img_in[adr-imgx]))/(8.0*255); /* gradient y component */
		  norm_square = gx*gx+gy*gy;
		  sum+=norm_square;

		  norm = sqrt( norm_square); /* gradient norm */

		  (mod)->data[adr] = norm; /* store gradient norm */
		   /* gradient angle computation */
	     (*angles)->data[adr] = atan2(gy,gx);
		}
	threshold = 2*sqrt(sum/(imgx*imgy));//�Զ���ֵ
	//non maximum suppression
	for(x=1;x<imgx-1;x++)
		for(y=1;y<imgy-1;y++)
		{
			adr = y*imgx+x;
			value = (*angles)->data[adr];
			if((mod)->data[adr] < threshold )
			{
				(*angles)->data[adr] = NOTDEF;
				continue;
			}
			if( (value > -M_1_8_PI && value<=M_1_8_PI) || (value <= -M_7_8_PI ) || (value > M_7_8_PI))
			{
				if((mod)->data[adr] <= (mod)->data[adr+1] || (mod)->data[adr] <= (mod)->data[adr-1])
					(*angles)->data[adr] = NOTDEF;
			}
			else if( (value> M_1_8_PI && value<= M_3_8_PI) || (value> -M_7_8_PI && value<= -M_5_8_PI) )
			{
				if((mod)->data[adr] <= (mod)->data[adr-imgx-1] || (mod)->data[adr] <= (mod)->data[adr+imgx+1])
					(*angles)->data[adr] = NOTDEF;
			}
			else if((value> M_3_8_PI && value<= M_5_8_PI) || (value> -M_5_8_PI && value<= -M_3_8_PI))
			{
				if((mod)->data[adr] <= (mod)->data[adr-imgx] || (mod)->data[adr] <= (mod)->data[adr+imgx])
					(*angles)->data[adr] = NOTDEF;
			}
			else 
			{
				if((mod)->data[adr] <= (mod)->data[adr-imgx+1] || (mod)->data[adr] <= (mod)->data[adr+imgx-1])
					(*angles)->data[adr] = NOTDEF;
			}
		}
    //Ҳ��ǵ�modͼ����
	//for(x=1;x<imgx-1;x++)
	//	for(y=1;y<imgy-1;y++)
	//	{
	//		if((*angles)->data[y*imgx+x] == NOTDEF)
	//			(*mod)->data[y*imgx+x] = NOTDEF;
	//	}
	free_image_double(mod);
}

void cvCanny3(	const void* srcarr, void* dstarr,
				void* dxarr, void* dyarr,
                int aperture_size )
{
    //cv::Ptr<CvMat> dx, dy;
    cv::AutoBuffer<char> buffer;
    std::vector<uchar*> stack;
    uchar **stack_top = 0, **stack_bottom = 0;

    CvMat srcstub, *src = cvGetMat( srcarr, &srcstub );
    CvMat dststub, *dst = cvGetMat( dstarr, &dststub );

	CvMat dxstub, *dx = cvGetMat( dxarr, &dxstub );
	CvMat dystub, *dy = cvGetMat( dyarr, &dystub );


    CvSize size;
    int flags = aperture_size;
    int low, high;
    int* mag_buf[3];
    uchar* map;
    ptrdiff_t mapstep;
    int maxsize;
    int i, j;
    CvMat mag_row;

    if( CV_MAT_TYPE( src->type ) != CV_8UC1 ||
        CV_MAT_TYPE( dst->type ) != CV_8UC1 ||
		CV_MAT_TYPE( dx->type  ) != CV_16SC1 ||
		CV_MAT_TYPE( dy->type  ) != CV_16SC1 )
        CV_Error( CV_StsUnsupportedFormat, "" );

    if( !CV_ARE_SIZES_EQ( src, dst ))
        CV_Error( CV_StsUnmatchedSizes, "" );
	
    aperture_size &= INT_MAX;
    if( (aperture_size & 1) == 0 || aperture_size < 3 || aperture_size > 7 )
        CV_Error( CV_StsBadFlag, "" );


	size.width = src->cols;
    size.height = src->rows;

	//aperture_size = -1; //SCHARR
    cvSobel( src, dx, 1, 0, aperture_size );
    cvSobel( src, dy, 0, 1, aperture_size );

	Mat1f magGrad(size.height, size.width, 0.f);
	float maxGrad(0);
	float val(0);
	for(i=0; i<size.height; ++i)
	{
		float* _pmag = magGrad.ptr<float>(i);
		const short* _dx = (short*)(dx->data.ptr + dx->step*i);
        const short* _dy = (short*)(dy->data.ptr + dy->step*i);
		for(j=0; j<size.width; ++j)
		{
			val = float(abs(_dx[j]) + abs(_dy[j]));
			_pmag[j] = val;
			maxGrad = (val > maxGrad) ? val : maxGrad;
		}
	}
	
	//% Normalize for threshold selection
	//normalize(magGrad, magGrad, 0.0, 1.0, NORM_MINMAX);

	//% Determine Hysteresis Thresholds
	
	//set magic numbers
	const int NUM_BINS = 64;	
	const double percent_of_pixels_not_edges = 0.95; //0.9
	const double threshold_ratio = 0.4; //0.3

	//compute histogram
	int bin_size = cvFloor(maxGrad / float(NUM_BINS) + 0.5f) + 1;
	if (bin_size < 1) bin_size = 1;
	int bins[NUM_BINS] = { 0 }; 
	for (i=0; i<size.height; ++i) 
	{
		float *_pmag = magGrad.ptr<float>(i);
		for(j=0; j<size.width; ++j)
		{
			int hgf = int(_pmag[j]);
			bins[int(_pmag[j]) / bin_size]++;
		}
	}	

	
	

	//% Select the thresholds
	
	float total(0.f);	
	float target = float(size.height * size.width * percent_of_pixels_not_edges);
	int low_thresh, high_thresh(0);
	
	while(total < target)
	{
		total+= bins[high_thresh];
		high_thresh++;
	}
	high_thresh *= bin_size;
	low_thresh = cvFloor(threshold_ratio * float(high_thresh));
	
    if( flags & CV_CANNY_L2_GRADIENT )
    {
        Cv32suf ul, uh;
        ul.f = (float)low_thresh;
        uh.f = (float)high_thresh;

        low = ul.i;
        high = uh.i;
    }
    else
    {
        low = cvFloor( low_thresh );
        high = cvFloor( high_thresh );
    }
    
	buffer.allocate( (size.width+2)*(size.height+2) + (size.width+2)*3*sizeof(int) );
    mag_buf[0] = (int*)(char*)buffer;
    mag_buf[1] = mag_buf[0] + size.width + 2;
    mag_buf[2] = mag_buf[1] + size.width + 2;
    map = (uchar*)(mag_buf[2] + size.width + 2);
    mapstep = size.width + 2;

    maxsize = MAX( 1 << 10, size.width*size.height/10 );
    stack.resize( maxsize );
    stack_top = stack_bottom = &stack[0];

    memset( mag_buf[0], 0, (size.width+2)*sizeof(int) );
    memset( map, 1, mapstep );
    memset( map + mapstep*(size.height + 1), 1, mapstep );

    /* sector numbers
       (Top-Left Origin)

        1   2   3
         *  *  *
          * * *
        0*******0
          * * *
         *  *  *
        3   2   1
    */

    #define CANNY_PUSH(d)    *(d) = (uchar)2, *stack_top++ = (d)
    #define CANNY_POP(d)     (d) = *--stack_top

    mag_row = cvMat( 1, size.width, CV_32F );

    // calculate magnitude and angle of gradient, perform non-maxima supression.
    // fill the map with one of the following values:
    //   0 - the pixel might belong to an edge
    //   1 - the pixel can not belong to an edge
    //   2 - the pixel does belong to an edge
    for( i = 0; i <= size.height; i++ )
    {
        int* _mag = mag_buf[(i > 0) + 1] + 1;
        float* _magf = (float*)_mag;
        const short* _dx = (short*)(dx->data.ptr + dx->step*i);
        const short* _dy = (short*)(dy->data.ptr + dy->step*i);
        uchar* _map;
        int x, y;
        ptrdiff_t magstep1, magstep2;
        int prev_flag = 0;

        if( i < size.height )
        {
            _mag[-1] = _mag[size.width] = 0;

            if( !(flags & CV_CANNY_L2_GRADIENT) )
                for( j = 0; j < size.width; j++ )
                    _mag[j] = abs(_dx[j]) + abs(_dy[j]);

            else
            {
                for( j = 0; j < size.width; j++ )
                {
                    x = _dx[j]; y = _dy[j];
                    _magf[j] = (float)std::sqrt((double)x*x + (double)y*y);
                }
            }
        }
        else
            memset( _mag-1, 0, (size.width + 2)*sizeof(int) );

        // at the very beginning we do not have a complete ring
        // buffer of 3 magnitude rows for non-maxima suppression
        if( i == 0 )
            continue;

        _map = map + mapstep*i + 1;
        _map[-1] = _map[size.width] = 1;

        _mag = mag_buf[1] + 1; // take the central row
        _dx = (short*)(dx->data.ptr + dx->step*(i-1));
        _dy = (short*)(dy->data.ptr + dy->step*(i-1));

        magstep1 = mag_buf[2] - mag_buf[1];
        magstep2 = mag_buf[0] - mag_buf[1];

        if( (stack_top - stack_bottom) + size.width > maxsize )
        {
            int sz = (int)(stack_top - stack_bottom);
            maxsize = MAX( maxsize * 3/2, maxsize + 8 );
            stack.resize(maxsize);
            stack_bottom = &stack[0];
            stack_top = stack_bottom + sz;
        }

        for( j = 0; j < size.width; j++ )
        {
            #define CANNY_SHIFT 15
            #define TG22  (int)(0.4142135623730950488016887242097*(1<<CANNY_SHIFT) + 0.5)

            x = _dx[j];
            y = _dy[j];
            int s = x ^ y;
            int m = _mag[j];

            x = abs(x);
            y = abs(y);
            if( m > low )
            {
                int tg22x = x * TG22;
                int tg67x = tg22x + ((x + x) << CANNY_SHIFT);

                y <<= CANNY_SHIFT;

                if( y < tg22x )
                {
                    if( m > _mag[j-1] && m >= _mag[j+1] )
                    {
                        if( m > high && !prev_flag && _map[j-mapstep] != 2 )
                        {
                            CANNY_PUSH( _map + j );
                            prev_flag = 1;
                        }
                        else
                            _map[j] = (uchar)0;
                        continue;
                    }
                }
                else if( y > tg67x )
                {
                    if( m > _mag[j+magstep2] && m >= _mag[j+magstep1] )
                    {
                        if( m > high && !prev_flag && _map[j-mapstep] != 2 )
                        {
                            CANNY_PUSH( _map + j );
                            prev_flag = 1;
                        }
                        else
                            _map[j] = (uchar)0;
                        continue;
                    }
                }
                else
                {
                    s = s < 0 ? -1 : 1;
                    if( m > _mag[j+magstep2-s] && m > _mag[j+magstep1+s] )
                    {
                        if( m > high && !prev_flag && _map[j-mapstep] != 2 )
                        {
                            CANNY_PUSH( _map + j );
                            prev_flag = 1;
                        }
                        else
                            _map[j] = (uchar)0;
                        continue;
                    }
                }
            }
            prev_flag = 0;
            _map[j] = (uchar)1;
        }

        // scroll the ring buffer
        _mag = mag_buf[0];
        mag_buf[0] = mag_buf[1];
        mag_buf[1] = mag_buf[2];
        mag_buf[2] = _mag;
    }

    // now track the edges (hysteresis thresholding)
    while( stack_top > stack_bottom )
    {
        uchar* m;
        if( (stack_top - stack_bottom) + 8 > maxsize )
        {
            int sz = (int)(stack_top - stack_bottom);
            maxsize = MAX( maxsize * 3/2, maxsize + 8 );
            stack.resize(maxsize);
            stack_bottom = &stack[0];
            stack_top = stack_bottom + sz;
        }

        CANNY_POP(m);

        if( !m[-1] )
            CANNY_PUSH( m - 1 );
        if( !m[1] )
            CANNY_PUSH( m + 1 );
        if( !m[-mapstep-1] )
            CANNY_PUSH( m - mapstep - 1 );
        if( !m[-mapstep] )
            CANNY_PUSH( m - mapstep );
        if( !m[-mapstep+1] )
            CANNY_PUSH( m - mapstep + 1 );
        if( !m[mapstep-1] )
            CANNY_PUSH( m + mapstep - 1 );
        if( !m[mapstep] )
            CANNY_PUSH( m + mapstep );
        if( !m[mapstep+1] )
            CANNY_PUSH( m + mapstep + 1 );
    }

    // the final pass, form the final image
    for( i = 0; i < size.height; i++ )
    {
        const uchar* _map = map + mapstep*(i+1) + 1;
        uchar* _dst = dst->data.ptr + dst->step*i;

        for( j = 0; j < size.width; j++ )
		{
            _dst[j] = (uchar)-(_map[j] >> 1);
		}
	}
}

void Canny3(	InputArray image, OutputArray _edges,
				OutputArray _sobel_x, OutputArray _sobel_y,
                int apertureSize, bool L2gradient )
{
    Mat src = image.getMat();
    _edges.create(src.size(), CV_8U);
	_sobel_x.create(src.size(), CV_16S);
	_sobel_y.create(src.size(), CV_16S);


    CvMat c_src = src, c_dst = _edges.getMat();
	CvMat c_dx = _sobel_x.getMat();
	CvMat c_dy = _sobel_y.getMat();


    cvCanny3(	&c_src, &c_dst, 
				&c_dx, &c_dy,
				apertureSize + (L2gradient ? CV_CANNY_L2_GRADIENT : 0));
}

void calculateGradient_canny( Mat img_in, image_double * angles)
{
	Mat1b E;
	Mat1s DX, DY;
	int imgx,imgy;
	short *_dx, *_dy;
	uchar* _e;
	int addr;
	imgx = img_in.cols;
	imgy = img_in.rows;

	Canny3(img_in, E, DX, DY,3, false);

	(*angles) = new_image_double(imgx,imgy);//�����Ҫ�ͷ�

	for (int y = 0; y<imgy; y++)
	{
		_dx = DX.ptr<short>(y);
		_dy = DY.ptr<short>(y);
		_e= E.ptr<uchar>(y);
		addr = y*imgx;
		for (int x = 0; x<imgx; x++)
		{
			if (_e[x] > 0 )//�Ǳ�Ե��
			{
				(*angles)->data[addr+x] = atan2(_dy[x],_dx[x]);
			}
			else //0 ���Ǳ�Ե��
				(*angles)->data[addr+x] = NOTDEF;
		}
	}
	/*namedWindow("e");
	imshow("e",E);
	waitKey();*/
	//static int count = 0;
	//count++;
	//imwrite("D:\\���׼���СԲ\\edges2\\"+ std::to_string(count) + ".bmp",E);
}

inline bool linearProgram( point2d a, point2d b, point2d line1_dir, point2d c, point2d d, point2d line2_dir,  double polarity, double linear_prog_dis_tolerance)
{
	point2d arc1_vec,arc2_vec,test_vec1,test_vec2,test_vec3; //��ָ��Բ�ĵ������Ͳ�������
	if( polarity == 1)// polarity is equal 1, arc vector = (dy,-dx)
	{
		arc1_vec.x = line1_dir.y;
		arc1_vec.y = -line1_dir.x;
		arc2_vec.x = line2_dir.y;
		arc2_vec.y = -line2_dir.x;
	}
	else// polarity is equal -1, arc vector = (-dy,dx)
	{
		arc1_vec.x = -line1_dir.y;
		arc1_vec.y = line1_dir.x;
		arc2_vec.x = -line2_dir.y;
		arc2_vec.y = line2_dir.x;
	}
	/*
	A-------B     line i
	C-------D     line j
	test_vec1 = AC
	test_vec2 = AD
	test_vec3 = BC
	*/
	//method 1
	test_vec1.x = c.x - a.x;
	test_vec1.y = c.y - a.y;
	test_vec2.x = d.x - a.x;
	test_vec2.y = d.y - a.y;
	test_vec3.x = c.x - b.x;
	test_vec3.y = c.y - b.y;
	if( dotProduct(arc1_vec,test_vec1) >= linear_prog_dis_tolerance && 
		dotProduct(arc1_vec,test_vec2) >= linear_prog_dis_tolerance &&  
		-dotProduct(arc2_vec,test_vec1) >= linear_prog_dis_tolerance &&  
		-dotProduct(arc2_vec,test_vec1) >= linear_prog_dis_tolerance 
		) //space linear program
		return TRUE;
	//method 2
	//test_vec1.x = (c.x + d.x - a.x - b.x)/2;
	//test_vec1.y = (c.y + d.y - a.y - b.y)/2;
	//test_vec2.x = - test_vec1.x;
	//test_vec2.y = - test_vec1.y;
	//if( dotProduct(arc1_vec,test_vec1) >= linear_prog_dis_tolerance &&
	//	dotProduct(arc2_vec,test_vec2) >= linear_prog_dis_tolerance )
	//	return TRUE;
	return FALSE;
}
inline bool calcCircleParametersAndValidate( double * lines, int line_num, int first_line_ind,int second_line_ind, image_double angles, double distance_tolerance, point3d * circle )
{
	/*
	dx1*(x-x1)+dy1*(y-y1)=0
	dx2*(x-x2)+dy2*(y-y2)=0
	x  =  c1*dy2-c2*dy1   /
	y    -c1*dx2+c2*dx1  /  (dx1*dy2 - dx2*dy1)

	AX = C => X = A^{-1}C
	*/
	point2d equationC;
	double  delta;
	point2d segCenter1,segCenter2;
	point2d line1_dir,line2_dir;
	double r1,r2;
	//double d1,d2;
	rect rec1,rec2;
	int validate_cnt,total_cnt;
	if(first_line_ind >= line_num  || second_line_ind >= line_num )
		error("calcCircleParametersAndValidate, line index corrupt");
	//calculate the circle (x,y,r)
	rec1.x1 = lines[first_line_ind*8];
	rec1.y1 = lines[first_line_ind*8+1];
	rec1.x2 = lines[first_line_ind*8+2];
	rec1.y2 = lines[first_line_ind*8+3];
	rec1.x  = (rec1.x1 + rec1.x2)/2;
	rec1.y  = (rec1.y1 + rec1.y2)/2;
	rec1.dx = lines[first_line_ind*8+4];
	rec1.dy = lines[first_line_ind*8+5];
	rec1.width = 2*distance_tolerance;
	rec1.polarity = (int)lines[first_line_ind*8+7];
	rec2.x1 = lines[second_line_ind*8];
	rec2.y1 = lines[second_line_ind*8+1];
	rec2.x2 = lines[second_line_ind*8+2];
	rec2.y2 = lines[second_line_ind*8+3];
	rec2.x  = (rec2.x1 + rec2.x2)/2;
	rec2.y  = (rec2.y1 + rec2.y2)/2;
	rec2.dx = lines[second_line_ind*8+4];
	rec2.dy = lines[second_line_ind*8+5];
	rec2.width = 2*distance_tolerance;
	segCenter1.x = rec1.x;
	segCenter1.y = rec1.y;
	segCenter2.x = rec2.x;
	segCenter2.y = rec2.y;
	line1_dir.x  = rec1.dx;
	line1_dir.y  = rec1.dy;
	line2_dir.x  = rec2.dx;
	line2_dir.y  = rec2.dy;
	equationC.x = dotProduct(segCenter1,line1_dir);
	equationC.y = dotProduct(segCenter2,line2_dir);
	delta = line1_dir.x*line2_dir.y - line1_dir.y*line2_dir.x;//��������ֻ�üн�>=15����߶ζԲ�����㽻�㣬����б�ʽ�������0.
	circle->x = ( equationC.x * line2_dir.y - equationC.y*line1_dir.y)/delta;
	circle->y = (-equationC.x * line2_dir.x + equationC.y*line1_dir.x)/delta;
	r1  = dist(circle->x, circle->y,rec1.x1,rec1.y1);//�뾶
    r2  = dist(circle->x, circle->y,rec2.x1,rec2.y1);
	//d1 = dist(circle->x, circle->y, segCenter1.x, segCenter1.y);//���ľ�
	//d2 = dist(circle->x, circle->y, segCenter2.x, segCenter2.y);
	//validate the radius
	//2*distance_tolerance
	if( abs(r1-r2) <= 2*distance_tolerance && min(r1,r2) > 3*distance_tolerance && max(r1,r2) < min(angles->xsize,angles->ysize) &&  circle->x > 0 && circle->x < angles->xsize && circle->y > 0 && circle->y < angles->ysize )
	//if( abs(d1-d2) <= 2*distance_tolerance && min(d1,d2) > 3*distance_tolerance && max(d1,d2) < min(angles->xsize,angles->ysize) &&  circle->x > 0 && circle->x < angles->xsize && circle->y > 0 && circle->y < angles->ysize )
	{
		circle->r = (r1+r2)/2;
		//circle->r = (d1+d2)/2;
		//validate the distribution rates of inliers
		rect_iter * ri1,*ri2;
		double point_normal,temp;
		if(rec1.polarity == 1)//����һ�£��ݶȷ����Բ��ָ������ͬ������ݶȷ����Բ��֧�����ص�ָ��Բ�ĵķ��߷���������ͬ
		{
			validate_cnt = total_cnt = 0;
			for(ri1 = ri_ini(&rec1);!ri_end(ri1);ri_inc(ri1))
			{
				//��Ӿ��ο��ܻ�Խ��
				if(ri1->x >= 0 && ri1->y >= 0 && ri1->x < angles->xsize && ri1->y < angles->ysize)
				{
					temp  = angles->data[ri1->y*angles->xsize+ri1->x] ;//�ڵ���ݶȷ���
					if(temp!= NOTDEF )
					{
						point_normal = atan2(circle->y - ri1->y,circle->x - ri1->x); //��Ե��ķ��߷���
						total_cnt++;
						if(angle_diff(point_normal,temp) <= M_1_9_PI && abs(dist(ri1->x,ri1->y,circle->x,circle->y)-circle->r) <= 3*distance_tolerance) //+- 20���� �� || d - r || < 3 dis_t
							validate_cnt++;
					}
				}
			}
			ri_del(ri1); //attention, must delete rect iterator, otherwise will cause memory leak.
			if(validate_cnt > 0 && validate_cnt*1.0/total_cnt >= 0.6)
			{
				validate_cnt = total_cnt = 0;
				for(ri2 = ri_ini(&rec2);!ri_end(ri2);ri_inc(ri2))
				{
					//��Ӿ��ο��ܻ�Խ��
					if(ri2->x >= 0 && ri2->y >= 0 && ri2->x < angles->xsize && ri2->y < angles->ysize)
					{
						temp  = angles->data[ri2->y*angles->xsize+ri2->x] ;//�ڵ���ݶȷ���
						if(temp!= NOTDEF )
						{
							point_normal = atan2(circle->y - ri2->y,circle->x - ri2->x); //��Ե���ָ��Բ�Ĳ෨�߷���
							total_cnt++;
							if(angle_diff(point_normal,temp) <= M_1_9_PI && abs(dist(ri2->x,ri2->y,circle->x,circle->y)-circle->r) <= 3*distance_tolerance) //+- 20���� �� || d - r || < 3 dis_t
								validate_cnt++;
						}
					}
				}
				ri_del(ri2); //attention, must delete rect iterator, otherwise will cause memory leak.
				if(validate_cnt > 0 && validate_cnt*1.0/total_cnt >= 0.6)
					return TRUE;
			}
		}
		else//�����෴���ݶȷ����Բ��ָ�����෴������ݶȷ����Բ��֧�����ص�ָ��Բ�ĵķ��߷��������෴
		{
			validate_cnt = total_cnt = 0;
			for(ri1 = ri_ini(&rec1);!ri_end(ri1);ri_inc(ri1))
			{
				//��Ӿ��ο��ܻ�Խ��
				if(ri1->x >= 0 && ri1->y >= 0 && ri1->x < angles->xsize && ri1->y < angles->ysize)
				{
					temp  = angles->data[ri1->y*angles->xsize+ri1->x] ;//�ڵ���ݶȷ���
					if(temp!= NOTDEF )
					{
						point_normal = atan2(ri1->y-circle->y, ri1->x-circle->x);  //Բ��ָ���Ե��෨�߷���
						total_cnt++;
						if(angle_diff(point_normal,temp) <= M_1_9_PI && abs(dist(ri1->x,ri1->y,circle->x,circle->y)-circle->r) <= 3*distance_tolerance) //+- 20���� �� || d - r || < 3 dis_t
							validate_cnt++;
					}
				}
			}
			ri_del(ri1); //attention, must delete rect iterator, otherwise will cause memory leak.
			if(validate_cnt > 0 && validate_cnt*1.0/total_cnt >= 0.6)
			{
				validate_cnt = total_cnt = 0;
				for(ri2 = ri_ini(&rec2);!ri_end(ri2);ri_inc(ri2))
				{
					//��Ӿ��ο��ܻ�Խ��
					if(ri2->x >= 0 && ri2->y >= 0 && ri2->x < angles->xsize && ri2->y < angles->ysize)
					{
						temp  = angles->data[ri2->y*angles->xsize+ri2->x] ;//�ڵ���ݶȷ���
						if(temp!= NOTDEF )
						{
							point_normal = atan2( ri2->y-circle->y, ri2->x-circle->x); //��Ե��ķ��߷���
							total_cnt++;
							if(angle_diff(point_normal,temp) <= M_1_9_PI && abs(dist(ri2->x,ri2->y,circle->x,circle->y)-circle->r) <= 3*distance_tolerance) //+- 20���� �� || d - r || < 3 dis_t
								validate_cnt++;
						}
					}
				}
				ri_del(ri2); //attention, must delete rect iterator, otherwise will cause memory leak.
				if(validate_cnt > 0 && validate_cnt*1.0/total_cnt >= 0.6)
					return TRUE;
			}
		}
	}
	return FALSE;
}
//lsd�㷨���õ����߶ε�����line_nums��return�ķ���ֵ��line_nums���߶Σ�Ϊһάdouble������lines������Ϊ8*n��ÿ8��Ϊһ��
//����x1,y1,x2,y2,dx,dy,width,polarity
//ע���ⲿ�ͷ�pairSegmentList�ṹ��ʱ��Ҫ��freePairedSegmentList
PairedSegmentList * getValidatePairedSegment( double * lines, int line_num, image_double angles, double distance_tolerance)
{
	PairedSegmentList * pairSegmentList = NULL;
	PairedSegmentNode *head, *tail;
	int pairlength = 0;
	point2d pointA,pointB,pointC,pointD,ab_dir,cd_dir;
	point3d circle;
	double polarity;
	//double distance_tolerance = max( 2.0, 0.005*min(angles->xsize,angles->ysize) ); // 0.005%*min(xsize,ysize)
	int i,j;
    double temp_dot;
	//pairSegmentList = pairedSegmentListInit(0);
	head = tail = NULL;
	for ( i = 0; i<line_num-1; i++)
		for ( j = i+1; j<line_num; j++)
		{
			//line i 's polarity is the same as line j
			//intersection angle great than 0�� and less than 180��
            temp_dot = (lines[i*8+4]*lines[j*8+4]+lines[i*8+5]*lines[j*8+5]);
			if( lines[i*8+7] == lines[j*8+7] &&  temp_dot < 1 && temp_dot> 0) //less than 90��
			//if( lines[i*8+7] == lines[j*8+7] && (lines[i*8+4]*lines[j*8+4]+lines[i*8+5]*lines[j*8+5]) <= cos(M_1_12_PI))//intersection angle great than 15��(1/12 * PI)
			//if(lines[i*8+7] == lines[j*8+7])
			{
				pointA.x = lines[i*8];
				pointA.y = lines[i*8+1];
				pointB.x = lines[i*8+2];
				pointB.y = lines[i*8+3];
				ab_dir.x = lines[i*8+4];
				ab_dir.y = lines[i*8+5];
				pointC.x = lines[j*8];
				pointC.y = lines[j*8+1];
				pointD.x = lines[j*8+2];
				pointD.y = lines[j*8+3];
				cd_dir.x = lines[j*8+4];
				cd_dir.y = lines[j*8+5];
				polarity = lines[i*8+7];
				if(linearProgram(pointA,pointB,ab_dir,pointC,pointD,cd_dir,polarity,-3*distance_tolerance))//���ڱ˴˵�����������
				{
					if(calcCircleParametersAndValidate(lines,line_num,i,j,angles,distance_tolerance,&circle))//���ľ�Ĳ�ֵ���ƣ��߶ε��ڵ�֧�ֱ���
					{
						PairedSegmentNode * node = (PairedSegmentNode*)malloc(sizeof(PairedSegmentNode));
						node->circle.x = circle.x;
						node->circle.y = circle.y;
						node->circle.r = circle.r;
						node->pairedSegInd.x = i;//��¼���߶ζ�(i,j)
						node->pairedSegInd.y = j;
						//node->next = NULL;//����
						if(head != NULL)
						{
							tail->next = node;
							tail = node;
						}
						else
						{
							head = tail = node;
						}
						pairlength++; //��������Ч���������Ҳ������Ч�ĺ�ѡԲ��������
					}
				}
				
			}
		}
	if(pairlength > 0)
	{
		PairedSegmentNode *p;
		p = head;
		pairSegmentList = pairedSegmentListInit(pairlength);
		for( i = 0; i<pairSegmentList->length; i++)
		{
			pairSegmentList->pairSeg[i].circle.x = p->circle.x;
			pairSegmentList->pairSeg[i].circle.y = p->circle.y;
			pairSegmentList->pairSeg[i].circle.r = p->circle.r;
			pairSegmentList->pairSeg[i].pairedSegInd.x = p->pairedSegInd.x;//��¼�߶ζ�(i,j),��lines�еĵ�i���߶κ͵�j���߶ι��ɵ�ƥ��Բ�������ЧԲ����
			pairSegmentList->pairSeg[i].pairedSegInd.y = p->pairedSegInd.y;
			p = p->next;
		}
		tail->next = NULL;
		while (head != NULL)
		{
			p = head;
			head = head->next;
			free(p);
		}
	}
	return pairSegmentList;
}


//===================================================================================================================
//����
//��points��һ����initializations��һ����ÿ��Ԫ�ص�ƽ�����ܺ�
double squaredDifference(int & nDims, double *& points, int & i, double *& initializations, int & j)
{
    double result = 0;
    for (int k = 0; k < nDims; ++k)
		result += pow(points[i*nDims+k] - initializations[j*nDims+k], 2);
    return result;
}
/**
 *����
 *prhs[0]: n x d�����ռ�
 *prhs[1]:��ֵƯ�Ƴ�ʼ��λ�ã���nxd�ռ����Ҿ�ֵƯ�Ƴ�ʼʱ��ʼ������λ��
 *prhs[2]:sigma = 1
 *prhs[3]:window parameter = distance_tolerance����window parameter = distance_tolerance/2
 *prhs[4]:�����������1e-6
 *prhs[5]:��������50
 *���
 *������λ�ã�λ�ø������ʼ������λ�ø���һ��,���ǽ�������µ�initPoints,Ҳ�������������������Ҳ�������������ʡ�ڴ�
 */
void meanShift( double * points, int nPoints, int nDims, double * & initPoints, int initLength, double sigma, double window_size, double accuracy_tolerance, int iter_times )
{
//	for (int i = 0; i<initLength; i++)
//		cout<<initPoints[2*i]<<'\t'<<initPoints[2*i+1]<<endl;
    int nQuerries = initLength;
    double * initializations = (double*)malloc(nQuerries * nDims * sizeof(double));
    memcpy(initializations, initPoints , nQuerries * nDims * sizeof(double));//copy

    double sigma2 = sigma*sigma;//sigmaƽ��
    double radius2 = window_size *window_size;//ƽ��
    double tolerance = accuracy_tolerance;
    int maxiters = iter_times;//����������
   //�������ʼ�����㼯һ����С�����ն�λ�㼯
    double * finals = (double*)malloc(nQuerries * nDims * sizeof(double));;//���ն�λ�㼯��ָ��
    memcpy(finals, initializations, nQuerries * nDims * sizeof(double));
	double * distances = (double*)malloc(nPoints*sizeof(double));
    //printf("meanShift: nPoints:%d \tnDims: %d \tnQuerries:%d \n",nPoints,nDims,nQuerries);//��ӡ
    for (int loop = 0; loop < nQuerries; ++loop)
    {
        int iters = 0;
        while (iters < maxiters)
        {
            bool flag = false;
            double denominator = 0;//��ĸ
            for (int i = 0; i < nPoints; ++i)//�����еĵ㼯���б������ҵ���������Բ���ڵĵ�
            {
                distances[i] = squaredDifference(nDims, points, i, initializations, loop);//������ƽ��
                if (distances[i] <= radius2)//�ڵ�loop���������ĵ���sqrt(radius2)Ϊ�뾶��Բ����
                {
                    flag = true;
                    denominator += exp(-distances[i] / sigma2);
                }
            }
            if (!flag)
                break;
            for (int j = 0; j < nDims; ++j)
				finals[loop*nDims+j] = 0;//�����ն�λ�㼯�еĵ�loop�����������ֵΪ0
            for (int i = 0; i < nPoints; ++i)
                if (distances[i] <= radius2)
                {
                    for (int j = 0; j < nDims; ++j)//ÿ���ڵ���������һ��Ȩֵ�ۼ�
						finals[loop*nDims+j] += exp(-distances[i] / sigma2) * points[i*nDims+j];
                }
            for (int j = 0; j < nDims; ++j)//Ȩֵ��һ��
				finals[loop*nDims+j] /= denominator;
            if (sqrt(squaredDifference(nDims, finals, loop, initializations, loop)) < tolerance)//������εĵ���������������ˣ�����Ϊ�Ѿ�������û��Ҫ�ټ�������
                break;
            iters = iters + 1;
            for (int j = 0; j < nDims; ++j)//���µ�������������
				initializations[loop*nDims+j] = finals[loop*nDims+j];
        }
    }
	memcpy(initPoints, finals, nQuerries * nDims * sizeof(double));
    free(distances);
    free(initializations);
	free(finals);
}

/***
 *����
 *prhs[0] : points,������ĵ���� n x d
 *prhs[1] ��pointsz��ÿһ����Ŀ�����k���㣬n x k
 *prhs[2] ��threshold ��������ľ�����ֵ
 *��� outPoints
 *plhs[0] : �����ĵ꼯 m x d 
 */
void clusterByDistance(double * points, int nPoints, int nDims, double distance_threshold,int number_control, double * & outPoints, int * nOutPoints)
{ 
	double threshold2 = distance_threshold*distance_threshold;
    std::vector<double*> centers;
    std::vector<int> counts;
    centers.clear();
    counts.clear();
	bool * labeled = (bool*)malloc(sizeof(bool)*nPoints);
    memset(labeled, 0, nPoints * sizeof(bool));//��ʼ��bool�ͱ�ǩΪ0
	if(nPoints == 1)
	{
		centers.push_back((double*)malloc(sizeof(double)*nDims));
		for (int k = 0; k < nDims; ++k)
			centers[centers.size() - 1][k] = points[k];
        counts.push_back(1);
	}
	else
	{
		for (int i = 0; i < nPoints-1; ++i)
		{
		    if (!labeled[i])
			{
		        labeled[i] = true;
				centers.push_back((double*)malloc(sizeof(double)*nDims));
		        counts.push_back(1);
		        for (int k = 0; k < nDims; ++k)
				{
				   centers[centers.size() - 1][k] = points[i*nDims+k];  
				}
		        for (int j = i+1; j < nPoints; ++j)
		        {
		            if (!labeled[j])
		            {
		                double d = 0;
		                for (int k = 0; k < nDims; ++k)
				            d += pow(centers[centers.size() - 1][k] / counts[centers.size() - 1] - points[j*nDims+k], 2);
		                if (d <= threshold2)
		                {
		                    ++counts[centers.size() - 1];
		                    for (int k = 0; k < nDims; ++k)
								centers[centers.size() - 1][k] += points[j*nDims+k];
		                    labeled[j] = true;
							if(counts[centers.size() - 1] >= number_control)//�����������ƣ���ֹ��ֵ����Ư��̫Զ  Բ�ľ���ʱ20  �뾶����ʱ10
								break;
		                }
		            }
		        }
		    }
		}
	}
    free(labeled);
    centers.shrink_to_fit();
    counts.shrink_to_fit();
    int m = (int) centers.size();
    outPoints = (double*)malloc(sizeof(double)*m*nDims);
	(*nOutPoints) = m;
    for (unsigned int i = 0; i < centers.size(); ++i)
    {
        for (int j = 0; j < nDims; ++j)
		{
			outPoints[i*nDims+j] = centers[i][j] / counts[i];
//			cout<<out[i*nDims+j]<<'\t';
		}
//		cout<<endl;
        free(centers[i]);
    }
    centers.resize(0);
    counts.resize(0);
}
//==============================================================================================================
//��ú�ѡԲ�ĵľ�������(xi,yi)
//���룺
//pairSegmentList
//�����
//Բ�ĵľ������� centersCandidates��һάdouble���飬 ��СΪ centersCandidates_num x 2
void  generateCenterCandidates( PairedSegmentList *pairSegmentList, double distance_tolerance, double *& centerCandidates, int * centerCandidates_num)
{
	double xmax,xmin,ymax,ymin,xdelta,ydelta;
	int nbins_x,nbins_y;
	int x,y;
	int i;
	unsigned int addr;
	xmax = ymax = 0;
	xmin = ymin = DBL_MAX;
	for( i = 0; i< pairSegmentList->length; i++ )
	{
		if( pairSegmentList->pairSeg[i].circle.x > xmax)
			xmax = pairSegmentList->pairSeg[i].circle.x;
		if( pairSegmentList->pairSeg[i].circle.x < xmin)
			xmin = pairSegmentList->pairSeg[i].circle.x;
		if( pairSegmentList->pairSeg[i].circle.y > ymax)
			ymax = pairSegmentList->pairSeg[i].circle.y;
		if( pairSegmentList->pairSeg[i].circle.y < ymin)
			ymin = pairSegmentList->pairSeg[i].circle.y;
	}
	xdelta = (xmax-xmin);
	ydelta = (ymax-ymin);
	nbins_x = (int)ceil(xdelta*2/distance_tolerance);
	nbins_y = (int)ceil(ydelta*2/distance_tolerance);
	if(nbins_x <= 0 || nbins_y <= 0)
	{
		nbins_x = nbins_y = 1;//���ٱ���1��bin
		//error("generateCircleCandidates,nbins_x,nbins_y error");
	}
	point2d1i * center_bins;
	center_bins = (point2d1i *)malloc(sizeof(point2d1i)*nbins_y*nbins_x);//(x,y,z),x������sum(xi),y������sum(yi),z���������ڸ����������
	memset(center_bins,0,sizeof(point2d1i)*nbins_y*nbins_x);
	//for( i = 0; i<nbins_x*nbins_y; i++)
	//{
	//	center_bins[i].x = center_bins[i].y = 0;
	//	center_bins[i].z = 0;
	//}
	if(center_bins == NULL)
		error("generateCircleCandidates,not enough memory");
	for ( i = 0; i< pairSegmentList->length; i++ )//��Բ�ļ�¼���������棬ͬʱ������Ӧ�������������++
	{
		x = (int)((pairSegmentList->pairSeg[i].circle.x - xmin)/xdelta*nbins_x+0.5);//��������
		y = (int)((pairSegmentList->pairSeg[i].circle.y - ymin)/ydelta*nbins_y+0.5);
		x = x<0 ? 0 :x;
		x = x>= nbins_x ? (nbins_x-1):x;
		y = y<0 ? 0 :y;
		y = y>= nbins_y ? (nbins_y-1):y;
		addr = y*nbins_x+x;
		center_bins[addr].x += pairSegmentList->pairSeg[i].circle.x;
		center_bins[addr].y += pairSegmentList->pairSeg[i].circle.y;
		center_bins[addr].z ++;
	}
	Point2dNode * head, * tail ;
	int initCentersLength = 0;
	head = tail = NULL;
	for ( y = 0; y<nbins_y; y++)//��vote���0�ĸ��������Բ��ȡ��ֵ������¼����������
		for ( x = 0; x<nbins_x; x++)
		{
			addr = y*nbins_x+x;
			if(center_bins[addr].z > 0)
			{
				Point2dNode * node = (Point2dNode*)malloc(sizeof(Point2dNode));
				node->point.x = center_bins[addr].x/center_bins[addr].z;
				node->point.y = center_bins[addr].y/center_bins[addr].z;
				initCentersLength++;
				if(head != NULL)
				{
					tail->next = node;
					tail = node;
					tail->next = NULL;//����
				}
				else
				{
					head = tail = node;
				}
			}
		}
	if(initCentersLength == 0)
	{
		(*centerCandidates_num) = 0;
		centerCandidates = NULL;
		//error("generateCircleCandidates,initCentersLength equals 0");
	}
	free(center_bins);//�Ͻ��ͷŸ��ڴ�
	double * initCenters; //initCentersLength x 2
	initCenters = (double*)malloc(sizeof(double)*initCentersLength*2); 
	tail = head;//����tail
	//����¼����������ķ������Բ�ľ�ֵ��¼�������������Ϊ��ʼ����о�ֵƯ��
	for ( i = 0; i<initCentersLength; i++ )// initCenters ��С�� initCentersLength*2
	{
		//һ�߼�¼��double���飬һ���ͷ��ڴ�
		int addr = 2*i;
		initCenters[addr] = tail->point.x;
		initCenters[addr+1] = tail->point.y;
		head = tail;       
		tail = tail->next;
		free(head);
	}
//	for (int  i = 0; i<initCentersLength; i++)
//		cout<<initCenters[2*i]<<'\t'<<initCenters[2*i+1]<<endl;

	double * originCenters;
	originCenters = (double*)malloc(sizeof(double)*pairSegmentList->length*2); //ԭʼ��Բ�ļ������� x 2
	for ( i = 0; i<pairSegmentList->length; i++)//ԭʼԲ�ļ��ϸ��Ƶ�double������
	{
		originCenters[i]   = pairSegmentList->pairSeg[i].circle.x;
		originCenters[i+1] = pairSegmentList->pairSeg[i].circle.y;
	}
	//��ֵƯ�ƵĽ������µ�initCenters����
	meanShift(originCenters,pairSegmentList->length,2,initCenters,initCentersLength,1,distance_tolerance/2,1e-6,50);
//	for (int  i = 0; i<initCentersLength; i++)
//		cout<<initCenters[2*i]<<'\t'<<initCenters[2*i+1]<<endl;
	//����
//	double * centerCandidates;//== candidateCenters_num x 2    (xi,yi)
//	int centerCandidates_num;
	free(originCenters);//�ͷ��ڴ�
	//ǧ��Ҫע��centerCandidates_num��int��ָ�룬++--ʱҪ(*centerCandidates_num).
	clusterByDistance(initCenters,initCentersLength,2,distance_tolerance,20,centerCandidates, centerCandidates_num);
	if (initCenters != NULL)
		free(initCenters);
//	cout<<"candidateCenters_num(Բ�ľ�ֵƯ�ƺ;��������):"<<(*centerCandidates_num)<<endl;
//	return centerCandidates;
}

void  generateCircleCandidates( PairedSegmentList *pairSegmentList, double * centerCandidates, int centerCandidates_num, double distance_tolerance, double *& circleCandidates, int * circleCandidates_num)
{
	Point3dNode * circleCandidates_head,*circleCandidates_tail;//�������ĺ�ѡԲ����(x,y,r)�ȴ洢�������Ȼ���ٷŵ�һά����circleCandidates�У�circleCandidates_num x 3
	circleCandidates_head = circleCandidates_tail = NULL; //��ʼ��ΪNULL
	(*circleCandidates_num) = 0;//�����ĺ�ѡԲ������ʼ��Ϊ0

	double dismin,temp;
	int ind;
	int i,j;
	Point1dNode ** head, **tail;
	int * count;
	head = (Point1dNode**)malloc(sizeof(Point1dNode*)*centerCandidates_num);
	tail = (Point1dNode**)malloc(sizeof(Point1dNode*)*centerCandidates_num);
	count = (int *)malloc(sizeof(int)*centerCandidates_num);
	memset(head,NULL,sizeof(Point1dNode*)*centerCandidates_num);//��ʼ��ΪNULL
	memset(tail,NULL,sizeof(Point1dNode*)*centerCandidates_num);
	memset(count,0,sizeof(int)*centerCandidates_num);//��ʼ��Ϊ0
	//����Ҫ����ʼ��Բ�ļ��ϰ��վ��������ķ��࣬�õ�ÿ���������Ŀ��ܵİ뾶
	for ( i = 0; i<pairSegmentList->length; i++)
	{
	    dismin = DBL_MAX;
		ind    = -1;
		for ( j = 0; j<centerCandidates_num; j++)
		{
			temp = dist(pairSegmentList->pairSeg[i].circle.x , pairSegmentList->pairSeg[i].circle.y, centerCandidates[2*j],centerCandidates[2*j+1]);
			if(temp < dismin)
			{
				ind = j;
				dismin = temp;
			}
		}
		Point1dNode * node = (Point1dNode*)malloc(sizeof(Point1dNode));
//		if(ind == 202)
//			ind = 202;
		node->data =pairSegmentList->pairSeg[i].circle.r;
		count[ind]++;  //����
		if(head[ind] != NULL)
		{
			tail[ind]->next = node;
			tail[ind] = node;
			//tail[ind]->next = NULL;
		}
		else
			head[ind] = tail[ind] = node;
	}
	//��ÿһ������Բ�ĵĿ��ܵİ뾶���о���
	for ( i = 0; i<centerCandidates_num; i++ )
	{
		int      origin_r_length = count[i];
		double * origin_r = (double*)malloc(sizeof(double)*origin_r_length);
		Point1dNode * p,*releasep;
		double rmin,rmax,rdelta;
		rmin = DBL_MAX;
		rmax = 0;
		p = head[i];
		for( j  = 0; j < origin_r_length; j++)//���������r���ϸ��Ƶ�����
		{
			if(p->data < rmin)//����һ�α����У���¼�����Сֵ
				rmin = p->data;
			if(p->data > rmax)
				rmax = p->data;
			origin_r[j] = p->data;
			releasep = p;
			p = p->next;
			free(releasep);//һ�߷�����һ���ͷ�һ������Բ�Ķ�Ӧ��r����ʱ������ڴ�
		}
		//�������Ǳ�õ���Բ�ľ�������(xi,yi) = (centerCandidates[2*i],centerCandidates[2*i+1])�����ܵ�r���� r[r_length].
		int nbins_r = 0;
		point1d1i * r_bins;
		rmax += rmin*0.05;//����rmax-rmin = 0
		rmin -= rmin*0.05;
		rdelta = rmax - rmin;
		nbins_r = (int)ceil(2*(rdelta)/distance_tolerance); //�˴���ԭ���ĵ��в�ͬ
	    if(nbins_r <= 0)//������һ��bin
			nbins_r = 1;
		r_bins = (point1d1i *)malloc(sizeof(point1d1i)*nbins_r);
		memset(r_bins,0,sizeof(point1d1i)*nbins_r);//��ʼ��Ϊ0
		for( j = 0; j<origin_r_length; j++)//�Է���vote
		{
			ind = int((origin_r[j]-rmin)/rdelta*nbins_r+0.5);
			ind = ind < 0 ? 0 : ind;
			ind = ind >= nbins_r ? (nbins_r-1) : ind;
			r_bins[ind].data += origin_r[j];
			r_bins[ind].cnt  ++;			
		}
		int init_r_length = 0;
		double * init_r ;//= (double*)malloc(sizeof(double)*r_length);
		for( j = 0; j<nbins_r; j++)
		{
			if(r_bins[j].cnt > 0)//ͳ�Ʒ�0����
			{
				init_r_length++;
			}
		}
		init_r = (double*)malloc(sizeof(double)*init_r_length);
		ind = 0;
		for( j = 0; j<nbins_r; j++)
		{
			if(r_bins[j].cnt > 0)//����ֵ�ƶ���������˴��ıȽ��ظ���2��,����Ż���
			{
				init_r[ind++] = r_bins[j].data/r_bins[j].cnt;  //ȡ��ֵ
			}
		}
		free(r_bins);//�ͷŷ���ʱ������ڴ�
		//���ˣ����ǵĵ��˾�ֵƯ�Ƴ�ʼ��ri��Ϊһάdouble����init_r��������init_r_len
		meanShift(origin_r,origin_r_length,1,init_r,init_r_length,1,distance_tolerance/2,1e-6,50);
		free(origin_r);//�ͷŵ�i������Բ�Ķ�Ӧ��ԭʼr����
		double * r_candidates;
		int r_candidates_num;
		clusterByDistance(init_r,init_r_length,1,distance_tolerance,10,r_candidates,&r_candidates_num);
		free(init_r);//free, otherwise will cause memory leak
		if(r_candidates_num <= 0)//����
		{
			continue;  //����Ϊʲô���������ĵ���Χȷû��������ĵ�
			//cout<<centerCandidates[202*2]<<'\t'<<centerCandidates[202+1]<<endl;
			system("pause");
			error("generateCircleCandidates,r_candidates_num<=0");
		}
		for( j = 0; j<r_candidates_num; j++)
		{
			Point3dNode * node = (Point3dNode *)malloc(sizeof(Point3dNode));
			node->point.x = centerCandidates[2*i];
			node->point.y = centerCandidates[2*i+1];
			node->point.r = r_candidates[j];
			if(circleCandidates_head != NULL)
			{
				circleCandidates_tail->next = node;
				circleCandidates_tail = node;
				(*circleCandidates_num)++;  //��ѡԲ�������++
			}
			else
				circleCandidates_head = circleCandidates_tail = node;
		}

		free(r_candidates);//�ͷź�ѡr
	}
//	free(centerCandidates);//�ͷź�ѡԲ��
	free(head);
	free(tail);
	free(count);
	
//	cout<<"��ѡԲ�������Ϊ��"<<*circleCandidates_num<<endl;
	//ǧ��Ҫע��circleCandidates_num��int��ָ�룬++--ʱҪ(*circleCandidates_num).
	circleCandidates = (double*)malloc(sizeof(double)*(*circleCandidates_num)*3);
    //����ѡԲ�������и��Ƶ�double����circleCandidates��
	for( i = 0; i < (*circleCandidates_num); i++)
	{
		int addr = 3*i;
		circleCandidates[addr]   = circleCandidates_head->point.x;
		circleCandidates[addr+1] = circleCandidates_head->point.y;
		circleCandidates[addr+2] = circleCandidates_head->point.r;
		circleCandidates_tail = circleCandidates_head;
		circleCandidates_head = circleCandidates_head->next;
		free(circleCandidates_tail);//һ��ת�ƣ�һ���ͷź�ѡԲ����
	}

	/*fstream file1;
	file1.open("D:\\Graduate Design\\picture\\sp\\circlecandidates.txt",ios::out | ios::trunc);
	file1.close();
	file1.open("D:\\Graduate Design\\picture\\sp\\circlecandidates.txt",ios::out | ios::app);
	file1<<"the  combination center and radii(circle candidates)num is :"<<*circleCandidates_num<<endl;
	for( i = 0; i < (*circleCandidates_num); i++)
	{
		int addr = 3*i;
		file1<<circleCandidates[addr]<<'\t'<<circleCandidates[addr+1]<<'\t'<<circleCandidates[addr+2]<<endl;
	}
	file1.close();*/
}
 
//δ֪Բ�ļ������ڵ㣬���򽫻�ͳ���ڵ㣬�����ؿ��ܵļ���1����-1��
void findInliers1(image_double map, point3d circle, double distance_tolerance, double normal_tolerance, point2i *& inliers, int * inlier_num, int * polarity)
{
	//Ѱ���ڵ㣬��ͳ�Ƽ��ԡ������Դ�inlier��0������ʼ�棬�����Դ�inlier��β��(map-xsize*map->ysize-1)��ʼ�档ע��inlier����ĳ�����map-xsize*map->ysize
	int pos_cnt, neg_cnt, total_len;
	pos_cnt = neg_cnt = 0; 
	total_len = map->xsize*map->ysize;
	int xstart,ystart,xend,yend;
	int addr,jump;
	point2d delta;
	double norm;
	double temp1;
	jump = (int)( circle.r +  distance_tolerance + 0.5);
	xstart = max((int)(circle.x - jump),0);
	xend   = min((int)(circle.x + jump+0.5),map->xsize-1);
	ystart = max((int)(circle.y - jump),0);
	yend   = min((int)(circle.y + jump+0.5),map->ysize-1);
	jump = (int)(( circle.r - distance_tolerance )*0.7071); //(r-d_t)*sqrt(2)/2

	for (int y = ystart; y<=yend; y++)//��������������
	{
		addr = y*map->xsize;
		for (int x = xstart; x<=xend; x++)
		{
			if (map->data[addr+x] <= NOTDEF)//�Ǳ�Ե��,�����Ѿ������ʹ�ù��ı�Ե�㣬�Ǳ�Ե����ΪNOTDEF,�Ѿ�ʹ�ù���ΪNOTDEF-1��NOTDEF-2��...
				continue;
			delta.x = x - circle.x;
			delta.y = y - circle.y;
			if (abs(delta.x) <= jump && abs(delta.y) <= jump)//��������������
				continue;
			norm = sqrt(delta.x * delta.x + delta.y * delta.y);
			if ( ((norm - circle.r) <= distance_tolerance) && ((norm - circle.r) >= -distance_tolerance) )//�����ڵ�����
			{
				delta.x /= norm;
				delta.y /= norm;
				temp1 = delta.x * cos(map->data[addr+x]) + delta.y * sin(map->data[addr+x]);//�ڻ�
				if (temp1 < 0 )
				{
					if(acos(-temp1) <= normal_tolerance)//����Ϊ�����������ݶȷ������ƣ�Ϊ֧���ڵ�
					{
						inliers[pos_cnt].x = x;//��ͷ����ʼ��¼֧���ڵ�����
						inliers[pos_cnt].y = y;
						pos_cnt++;
					}
				}
				else
				{
					if(acos(temp1) <= normal_tolerance)//����Ϊ�����������ݶȷ������ƣ�Ϊ֧���ڵ�
					{
						neg_cnt++;
						inliers[total_len-neg_cnt].x = x;//��β����ʼ��¼֧���ڵ�����
						inliers[total_len-neg_cnt].y = y;
					}
				}
			}
		}
	}

	if ((pos_cnt + neg_cnt)>0)
	{
		if (pos_cnt >= neg_cnt)
		{
			*polarity = 1; //����Ϊ��
			*inlier_num = pos_cnt;
		}
		else
		{
			*polarity = -1;//����Ϊ��
			*inlier_num = neg_cnt;
			for (int i = 0; i<neg_cnt; i++)//ת�浽ͷ����0~neg_cnt-1
			{
				inliers[i].x = inliers[total_len-1-i].x;
				inliers[i].y = inliers[total_len-1-i].y;
			}
		}
	}
	else
	{
		*inlier_num = 0; //û��֧���ڵ�
		*polarity = 0;   //���Բ�ȷ��
	}
}
//��֪������֧���ڵ㣬��Ҫ��ʼ����ֵ��1����-1��
void findInliers2(image_double map, point3d circle, double distance_tolerance, double normal_tolerance, point2i *& inliers, int * inlier_num, int polarity)
{
	int cnt = 0;
	int xstart,ystart,xend,yend;
	int addr,jump;
	point2d delta;
	double norm;
	double temp1;
	jump = (int)( circle.r + distance_tolerance + 0.5);
	xstart = max((int)(circle.x - jump),0);
	xend   = min((int)(circle.x + jump+0.5),map->xsize-1);
	ystart = max((int)(circle.y - jump),0);
	yend   = min((int)(circle.y + jump+0.5),map->ysize-1);
	jump = (int)(( circle.r - distance_tolerance )*0.7071); //(r-d_t)*sqrt(2)/2

	for (int y = ystart; y<=yend; y++)//��������������
	{
		addr = y*map->xsize;
		for (int x = xstart; x<=xend; x++)
		{
			if (map->data[addr+x] <= NOTDEF)//�Ǳ�Ե��,�����Ѿ������ʹ�ù��ı�Ե�㣬�Ǳ�Ե����ΪNOTDEF,�Ѿ�ʹ�ù���ΪNOTDEF-1��NOTDEF-2��...
				continue;
			delta.x = x - circle.x;
			delta.y = y - circle.y;
			if (abs(delta.x) <= jump && abs(delta.y) <= jump)//��������������
				continue;
			norm = sqrt(delta.x * delta.x + delta.y * delta.y);
			if ( ((norm - circle.r) <= distance_tolerance) && ((norm - circle.r) >= -distance_tolerance) )//�����ڵ�����
			{
				delta.x /= norm;
				delta.y /= norm;
				temp1 = delta.x * cos(map->data[addr+x]) + delta.y * sin(map->data[addr+x]);//�ڻ�
				if (temp1 < 0 && polarity == 1)
				{
					if(acos(-temp1) <= normal_tolerance)//����Ϊ�����������ݶȷ������ƣ�Ϊ֧���ڵ�
					{
						inliers[cnt].x = x;//��ͷ����ʼ��¼֧���ڵ�����
						inliers[cnt].y = y;
						cnt++;
					}
				}
				else if (temp1 > 0 && polarity == -1)
				{
					if(acos(temp1) <= normal_tolerance)//����Ϊ�����������ݶȷ������ƣ�Ϊ֧���ڵ�
					{
						inliers[cnt].x = x;//��β����ʼ��¼֧���ڵ�����
						inliers[cnt].y = y;
						cnt++;
					}
				}
			}
		}
	}
	*inlier_num = cnt;		
}

//��ÿһ����ͨ��������ͨ��������ֻȡ����ͨ����������ͨ��
int pointCompare(point2i a, point2i b){return a.y < b.y;}
void inliersRefinement(vector<vector<point2i>> * finalcomponents, point3d circle, double distance_tolerance)
{
	int r,labelmapx, labelmapy;
	int **labelmap;
	vector<vector<point2i>> finalcomponentsTemp;
	int offset_x,offset_y;
	r = (int)(circle.r + 2*distance_tolerance);
	offset_x = -(int)circle.x+r;
	offset_y = -(int)circle.y+r;
	labelmapx = labelmapy = r*2;
	labelmap = (int**)calloc(labelmapy,sizeof(int*));//create 2D label map
	for (int i = 0; i<labelmapy; i++)
	{
		labelmap[i] = (int*)calloc(labelmapx,sizeof(int));
	    memset(labelmap[i],0,sizeof(int)*labelmapx);
	}
	point2i pointtemp,pointcurrent;
	vector<point2i> listtemp;
	int component_cnt;
	vector<vector<point2i>> subcomponents;
	queue<point2i> pointqueue;
	//����ƽ��
	for (unsigned int i = 0; i<(*finalcomponents).size(); i++)
	{
		finalcomponentsTemp.push_back(listtemp);
		for (unsigned int j = 0; j<(*finalcomponents)[i].size(); j++)
		{
			pointtemp.x = (*finalcomponents)[i][j].x+offset_x;
			pointtemp.y = (*finalcomponents)[i][j].y+offset_y;
			finalcomponentsTemp[i].push_back(pointtemp);
			labelmap[pointtemp.y][pointtemp.x]=-1;//��ǵ�n��component, �Ǻ�Ϊ-1
		}
		component_cnt = 0;//��0
		subcomponents.clear();//clear
		while(!pointqueue.empty())//��ն���
			pointqueue.pop();
		for (unsigned int j = 0; j<finalcomponentsTemp[i].size(); j++)//��ͨ�Ա��
		{
			if (labelmap[finalcomponentsTemp[i][j].y][finalcomponentsTemp[i][j].x] == -1 )
			{
				component_cnt++;//��component_cnt������,�µķ�����1~n
				//inlier_cnt = 0; //clear
				subcomponents.push_back(listtemp);
				labelmap[finalcomponentsTemp[i][j].y][finalcomponentsTemp[i][j].x] = component_cnt;//��ǵ�component_cnt������
				pointqueue.push(finalcomponentsTemp[i][j]);//������
				while(!pointqueue.empty())//�ǿ�
				{
					pointcurrent = pointqueue.front();//ȡ��
					subcomponents[component_cnt-1].push_back(pointcurrent);//���
					pointqueue.pop();//������
					//inlier_cnt ++; //��¼�ڵ���
					for (int k = pointcurrent.y-1; k<=(pointcurrent.y+1); k++)//8-neighbor search 
						for (int t = pointcurrent.x-1; t<=(pointcurrent.x+1); t++)
						{
							if (k>=0 && t>=0 && k<labelmapy && t<labelmapx && labelmap[k][t]== -1) 
							{
								labelmap[k][t] = component_cnt;//���
								pointtemp.x = t; 
								pointtemp.y = k;
								pointqueue.push(pointtemp);//ѹ������
							}
						}
				}
			}
		}
		listtemp.clear();
		for (unsigned int k = 0; k<subcomponents.size(); k++)
		{
			pointtemp.x = k;
			pointtemp.y = subcomponents[k].size();
			listtemp.push_back(pointtemp);
		}
		sort(listtemp.begin(),listtemp.end(),pointCompare);//��������xֵΪ������ţ�yֵΪ�������ڵ�����
		int inliercount=0;//��β����ʼͳ�ƣ�ֱ�����ڵ���ԭ�ڵ�������2/3
		int threshold = ((*finalcomponents)[i].size()*2/3);
		int start_index;
		for (start_index = listtemp.size()-1; start_index>=0; start_index--)
		{
			inliercount += listtemp[start_index].y;
			if (inliercount >= threshold)
				break;
		}
		(*finalcomponents)[i].clear();//���
		for (unsigned int k = start_index; k<listtemp.size(); k++)
		{
			(*finalcomponents)[i].insert((*finalcomponents)[i].end(),subcomponents[listtemp[k].x].begin(),subcomponents[listtemp[k].x].end());
		}
		//��ԭ��ǣ���0
		for (unsigned int k = 0; k<finalcomponentsTemp[i].size(); k++)
			labelmap[finalcomponentsTemp[i][k].y][finalcomponentsTemp[i][k].x] = 0;//������
	}

	//��ԭ��ԭ����ϵ
	for (unsigned int i = 0; i<(*finalcomponents).size(); i++)
		for (unsigned int j = 0; j<(*finalcomponents)[i].size(); j++)
		{
			(*finalcomponents)[i][j].x -= offset_x; //ƫ����
			(*finalcomponents)[i][j].y -= offset_y;
		}
	//free
	for (int i = 0; i<labelmapy; i++)
	{
	    free(labelmap[i]);
	}
	free(labelmap);
}
//��ͨ�Է�������Բ���ϵ��ڵ�����ᴿ
//��ͨ��������new_num <= inlier_num
//�ú������Ľ������д����������
void takeInliers(point2i *& inliers, int inlier_num, point3d circle, int nbins, double distance_tolerance, int * new_num)
{
	vector<vector<point2i>> hist;
	int* histLabel=(int*)malloc(sizeof(int)*nbins);
	int* components=(int*)malloc(sizeof(int)*nbins);//�����㹻�ڴ棬��i����ͨ�����洢����ռ��bin����
	int  components_cnt = 0;//��ͨ����������
	int  bin_cnt;
	memset(histLabel,0,sizeof(int)*nbins);//��ʼ�����Ϊ0
	memset(components,0,sizeof(int)*nbins);
	double deltax,deltay,angle;
	int mapping_bin;
	vector<point2i> listtemp;
	for (int i = 0; i<nbins; i++)//��ʼ��ֱ��ͼ
	{
		hist.push_back(listtemp);
	}
	for (int i = 0; i<inlier_num; i++)//����ͳ��ֱ��ͼ
	{
		deltax = inliers[i].x - circle.x;
		deltay = inliers[i].y - circle.y;
		angle = atan2(deltay,deltax);//������
		mapping_bin = (int)((angle+M_PI)/M_2__PI*nbins+0.5);//+0.5,��������
		if (mapping_bin < 0)
			mapping_bin = 0;
		if (mapping_bin >= nbins)
			mapping_bin = nbins - 1;
		hist[mapping_bin].push_back(inliers[i]);//���ڵ�
	}
	bin_cnt = 0;
	int addr,start_addr=0;
	if (hist[0].size() > 0)//bin 0 has inliers
	{
		components_cnt = 1;
		histLabel[0] = components_cnt;//tag
		bin_cnt ++;
		addr = nbins-1;// search component from tail
		while ( addr >= 0 && histLabel[addr] == 0 && hist[addr].size() > 0)
		{
			histLabel[addr] = components_cnt;
			bin_cnt ++;
			addr--;
		}
		addr = 1;//search component from head
		while (addr < nbins && histLabel[addr] == 0 && hist[addr].size() > 0)
		{
			histLabel[addr] = components_cnt;
			bin_cnt ++;
			addr++;
		}
		start_addr = addr-1;
		components[components_cnt-1]=bin_cnt; //����i����ͨ������bin������Ҳ���ǳ��ȣ���¼��i-1��λ��
	}

	addr = start_addr;
    while(addr < nbins)
	{
		if (histLabel[addr] == 0 && hist[addr].size() > 0)
		{
			bin_cnt = 1;//reset to 1
			components_cnt++;
			histLabel[addr] = components_cnt;
			addr++;
			while (addr < nbins)
			{
				if(histLabel[addr] == 0 && hist[addr].size() > 0)
				{
					bin_cnt ++;
					histLabel[addr] = components_cnt;
					addr++;
				}
				else
					break;
			}
			components[components_cnt-1]=bin_cnt;
		}
		else
		{
			addr++;
		}
	}
	
	int max_length = 0;//the component of max length
	int threshold;

	for (int i = 0; i< components_cnt; i++)
	{
		if (components[i] >= max_length)
			max_length = components[i];
	}

	threshold = (int)(max_length*0.1);
	threshold =  (threshold >= 5 ? threshold:5);
	//maintain the inliers of the component whose length is greater than threshold
	/*(*new_num) = 0;
	for (unsigned int i = 0; i<nbins; i++)
	{
		if (histLabel[i] > 0)
		{
			if (components[histLabel[i]-1]>=threshold)
			{
				for (unsigned int j = 0; j<hist[i].size(); j++)
				{
					inliers[(*new_num)].x = hist[i][j].x;
					inliers[(*new_num)].y = hist[i][j].y;
					(*new_num)++;
				}
			}
		}
	}*/
	vector<int> componentIndex;
	vector<vector<point2i>> finalComponents;
	//�ҵ�������������ͨ���������
	for (int i = 0; i<components_cnt; i++)
	{
		if(components[i] >= threshold)
		{
			componentIndex.push_back(i+1);
			finalComponents.push_back(listtemp);
		}
	}
	//��hist�н�����ͬһ����ͨ������bin����ڵ㸴�Ƶ�ͬһ����
	unsigned int len1;
	len1 = componentIndex.size();
	for (unsigned int i = 0; i<len1; i++)
	{
		for (int j = 0; j<nbins; j++)
		{
			if (histLabel[j] == componentIndex[i])
			{
				finalComponents[i].insert(finalComponents[i].end(),hist[j].begin(),hist[j].end());
			}
		}
	}
	
	//inliersRefinement(&finalComponents,circle,distance_tolerance);

   (*new_num) = 0;
   for (unsigned int i = 0; i<finalComponents.size(); i++)
   {
	   for (unsigned int j = 0; j<finalComponents[i].size(); j++)
	   {
		   inliers[(*new_num)].x = finalComponents[i][j].x;
		   inliers[(*new_num)].y = finalComponents[i][j].y;
		   (*new_num)++;
	   }
   }
   
   //free
   free(histLabel);
   free(components);
} 

//very fast circle fitting
//inliers: ������ڵ�(xi,yi)��inier_numΪ�ڵ�����
//return a fitted circle (xc,yc,r), and a flag, flag = 1 means circle fitting using least-squares method, 
//while flag = 0 means using the mean value since the discriminant is near to 0.
void circleFitting(point2i * inliers, int inlier_num, point3d* fittedcircle, int* flag)
{
	double mean_x,mean_y;
	int max_x,max_y,min_x,min_y;
	double *ulist,*vlist;
	double uu,uv,vv,uuu,uuv,uvv,vvv;
	double uutemp,uvtemp,vvtemp;
	ulist = (double*)malloc(sizeof(double)*inlier_num);
	vlist = (double*)malloc(sizeof(double)*inlier_num);
	//calculate the mean value
	mean_x = mean_y = 0;
	max_x = max_y = INT_MIN;
	min_x = min_y = INT_MAX;
	for (int i = 0; i<inlier_num; i++)
	{
		mean_x += inliers[i].x;
		mean_y += inliers[i].y;
		if (inliers[i].x > max_x)
			max_x = inliers[i].x;
		if (inliers[i].y > max_y)
			max_y = inliers[i].y;
		if (inliers[i].x < min_x)
			min_x = inliers[i].x;
		if (inliers[i].y < min_y)
			min_y = inliers[i].y;
	}
	mean_x /= inlier_num;
	mean_y /= inlier_num;
	for (int i = 0; i<inlier_num; i++)
	{
		ulist[i] = inliers[i].x - mean_x;
		vlist[i] = inliers[i].y - mean_y;
	}
	uu = uv =vv = 0;
	uuu = uuv = uvv = vvv = 0;
	for (int i = 0; i<inlier_num; i++)
	{
		uutemp = ulist[i]*ulist[i];
		uvtemp = ulist[i]*vlist[i];
		vvtemp = vlist[i]*vlist[i];
		uu += uutemp;
		uv += uvtemp;
		vv += vvtemp;
		uuu+= uutemp*ulist[i];
		uuv+= uvtemp*ulist[i];
		uvv+= uvtemp*vlist[i];
		vvv+= vvtemp*vlist[i];
	}
	double delta = uu*vv-uv*uv;
	if (delta < 1e-6) //delta is too small
	{
		(*fittedcircle).x = mean_x;
		(*fittedcircle).y = mean_y;
		(*fittedcircle).r = min(max_x-min_x, max_y-min_y)*1.0/2;
		(*flag) = 0;
	}
	else
	{
		double c1,c2;
		double ucenter,vcenter;
		c1 = (uuu+uvv)/2;
		c2 = (vvv+uuv)/2;
		ucenter = (vv*c1-uv*c2)/delta;
		vcenter = (-uv*c1+uu*c2)/delta;
		(*fittedcircle).x = ucenter + mean_x;
		(*fittedcircle).y = vcenter + mean_y;
		(*fittedcircle).r = sqrt(ucenter*ucenter + vcenter*vcenter + (uu+vv)/inlier_num);
		(*flag) = 1;
	}
	//free
	free(ulist);
	free(vlist);
}

//���������ȣ�
double calcuCompleteness(point2i * inliers, int inlier_num, point3d circle, int nbins)
{
	double coverage = 0;
	int * hist = (int*)malloc(sizeof(int)*nbins);
	double deltax,deltay,angle;
	int mapping_bin;
	int count;
	for (int i = 0; i<nbins; i++)//��ʼ��ֱ��ͼ
	{
		hist[i]=0;
	}
	for (int i = 0; i<inlier_num; i++)//����ͳ��ֱ��ͼ
	{
		deltax = inliers[i].x - circle.x;
		deltay = inliers[i].y - circle.y;
		angle = atan2(deltay,deltax);//������
		mapping_bin = (int)((angle+M_PI)/M_2__PI*nbins+0.5);//+0.5,��������
		if (mapping_bin < 0)
			mapping_bin = 0;
		if (mapping_bin >= nbins)
			mapping_bin = nbins - 1;
		hist[mapping_bin]++;//����
	}
	count = 0;
	for (int i = 0; i<nbins; i++)
	{
		if (hist[i] > 0)
			count++;
	}
	//free
	free(hist);
	coverage = count*1.0*M_2__PI/nbins;
	return coverage;
}

//
void validateCircleCandidates(image_double angles, double * candidates, int candidate_num, double distance_tolerance, double normal_tolerance, double inlier_ratio, double angle_coverage,\
							  double *& circles, int * circle_num)
{
	//xsize: ���� ysize: ����
	image_double gradient_map = new_image_double(angles->xsize,angles->ysize);//�ǵ������Ҫfree
	memcpy(gradient_map->data,angles->data,sizeof(double)*angles->xsize*angles->ysize);
	int* candidates_label = (int*)malloc(sizeof(int)*candidate_num);//�ǵ������Ҫfree
	memset(candidates_label,0,sizeof(int)*candidate_num);//��ʼ��Ϊ0������ú�ѡԲ�Ѿ���֤�������Ϊ-1
	double * final_circles = (double*)malloc(sizeof(double)*candidate_num*4);//(x,y,r,polarity),�����㹻�ڴ�洢���ռ���Բ,�ǵ���������ȼ��ã�Ȼ��ֵ��circles��֮����Ҫfree
	int final_circle_num = 0; //�ǵ����ֵ��(*circle_num)
	point2i * inliers = (point2i*)malloc(sizeof(point2i)*angles->xsize*angles->ysize);//�����㹻�ڴ�洢֧���ڵ㣬�ǵ������Ҫfree
	int inlier_num = 0; //��Ч�ڵ����� <= angles->xsize*angles->ysize
	point2i * new_inliers = (point2i*)malloc(sizeof(point2i)*angles->xsize*angles->ysize);
	int new_inlier_num;
	int polarity; //��⵽��Բ�ļ���
	int isDuplicate;
	/*Vec3b vecB(255,0,0);
	int X = gradient_map->xsize;
	int Y = gradient_map->ysize;
	Mat edge_mat = Mat::zeros(Y,X,CV_8UC3);
    for ( int y = 0; y<Y; y++)
	  for ( int x = 0; x<X; x++)
	  {
		  edge_mat.at<Vec3b>(y,x) = (gradient_map->data[y*X+x] == -1024 ? 0:vecB);
	  }
	  namedWindow("w");
	  imshow("w",edge_mat);
	  waitKey();*/
	int distance_tolerance_between_twocircles = max( 2.0, 0.01*min(angles->xsize,angles->ysize) );//��ֵ����һ�����ʱ��Բ���н���ʱ��
	double tested_angles[5];//Ԥ��������֤
	int start_index = -1;
	tested_angles[4] = 340*1.0/360*M_2__PI;//ע��Ϊdouble������
	tested_angles[3] = 250*1.0/360*M_2__PI;
	tested_angles[2] = 160*1.0/360*M_2__PI;
	tested_angles[1] =  70*1.0/360*M_2__PI;
	for ( int i = 1; i <= 4; i++)
	{
		if (angle_coverage < tested_angles[i])
		{
			start_index = i-1;
			tested_angles[start_index]=angle_coverage;
			break;
		}
	}
	if (start_index == -1)//����angle_coverage >= 340/360*M_2__PI
	{
		start_index = 4;
		tested_angles[4] = angle_coverage;
	}
	int addr;
	point3d testCircle; //����֤�ĺ�ѡԲ
	point3d circleTemp;
	int circlefitting_flag;
	int nbins;
	double completeness;
	double maxRadius;
    if (gradient_map->xsize > gradient_map->ysize)
    	maxRadius = gradient_map->ysize;
    else
    	maxRadius = gradient_map->xsize;
	//ÿ����֤�ĽǶ�Ϊtested_angles[angleLoop]
	for ( int angleLoop = 4; angleLoop >= start_index; angleLoop--)
	{
		for ( int validateIndex = 0; validateIndex < candidate_num; validateIndex++)
		{
			if ( candidates_label[validateIndex] == 0 )//��validateIndex��Բ����֤����֤����Բ���߱���̭��Բ���ᱻ��ǳ�-1
			{
				addr = validateIndex*3;
				testCircle.x = candidates[addr];
				testCircle.y = candidates[++addr];
				testCircle.r = candidates[++addr];
				if (testCircle.r <= distance_tolerance)//��ѡԲ̫С
				{
					candidates_label[validateIndex] = -1;
					continue;
				}
				nbins = min(180,(int)(2*M_PI*testCircle.r*inlier_ratio));
				//��һ�θ��ݺ�ѡԲ��֧���ڵ�ʱ��δ֪��ѡԲ���ԣ�����Ҫ��֧���ڵ�ͳ�ƣ�������polarity ����findInliers1������,ȱ���ǿ��ܽ������Ŀ��ĺܽ���ͬ���Եĵ������������ɸĽ�
				findInliers1(gradient_map,testCircle,2*distance_tolerance,normal_tolerance,inliers,&inlier_num,&polarity);
			  
				/*Vec3b vecB(255,0,0),vecR(0,0,255),vecG(0,255,0);
			    int X = gradient_map->xsize;
			    int Y = gradient_map->ysize;
			    Mat edge_mat = Mat::zeros(Y,X,CV_8UC3);
				for ( int y = 0; y<Y; y++)
				  for ( int x = 0; x<X; x++)
				  {
					edge_mat.at<Vec3b>(y,x) = (gradient_map->data[y*X+x] == NOTDEF ? 0:vecB);
				  }
                for ( int i = 0; i < inlier_num; i++)
				{
					edge_mat.at<Vec3b>(inliers[i].y,inliers[i].x) = vecR;
				}
				cv::circle(edge_mat,cv::Point(testCircle.x+0.5,testCircle.y+0.5),testCircle.r+0.5,Scalar(255,255,255));
				namedWindow("t1");
			    imshow("t1",edge_mat);
			    waitKey();*/

				
					
				if (inlier_num < 2*M_PI*testCircle.r*inlier_ratio*0.5)//�ڵ����
				{
					candidates_label[validateIndex] = -1;
					continue;
				}

				takeInliers(inliers,inlier_num,testCircle,nbins,2*distance_tolerance,&inlier_num);//��ͨ���������µ�֧���ڵ�(inliers)����£��µ��ڵ㳤��Ҳ�����(inlier_num)
				
				
				/*for ( int i = 0; i < inlier_num; i++)
				{
					edge_mat.at<Vec3b>(inliers[i].y,inliers[i].x) = vecG;
				}
				namedWindow("t2");
			    imshow("t2",edge_mat);
			    waitKey();*/
				
				if (inlier_num < 2*M_PI*testCircle.r*inlier_ratio*0.5)//�ڵ����
				{
					candidates_label[validateIndex] = -1;
					continue;
				}
				//circle fitting
				circleFitting(inliers,inlier_num,&circleTemp,&circlefitting_flag);


				
				/*cv::circle(edge_mat,cv::Point(circleTemp.x+0.5,circleTemp.y+0.5),circleTemp.r+0.5,Scalar(0,255,0));
			    namedWindow("t3");
			    imshow("t3",edge_mat);
			    waitKey();*/



				if (circlefitting_flag == 1)//try to refine the result
				{
					if (sqrt((circleTemp.x - testCircle.x)*(circleTemp.x - testCircle.x)+(circleTemp.y-testCircle.y)*(circleTemp.y-testCircle.y))<= 4*distance_tolerance_between_twocircles \
						&& abs(circleTemp.r - testCircle.r)<=4*distance_tolerance_between_twocircles)
					{
						//twice finding the support inliers
						findInliers2(gradient_map,circleTemp,2*distance_tolerance,normal_tolerance,new_inliers,&new_inlier_num,polarity);
						takeInliers(new_inliers,new_inlier_num,circleTemp,nbins,2*distance_tolerance,&new_inlier_num);
						if (new_inlier_num >= inlier_num)
						{
							testCircle.x = circleTemp.x;
							testCircle.y = circleTemp.y;
							testCircle.r = circleTemp.r;
							circleFitting(new_inliers,new_inlier_num,&circleTemp,&circlefitting_flag);
							if (circlefitting_flag == 1)
							{
								inlier_num = new_inlier_num;
							    memcpy(inliers,new_inliers,sizeof(point2i)*new_inlier_num);//update
								testCircle.x = circleTemp.x;
								testCircle.y = circleTemp.y;
								testCircle.r = circleTemp.r;
							}
						}
					}
				}
				if (inlier_num >= int(2*M_PI*testCircle.r*inlier_ratio))//inliers' number should be enough
				{
					completeness = calcuCompleteness(inliers,inlier_num,testCircle,nbins);
					if( completeness >= tested_angles[angleLoop] )//completeness check
					{
						//����Ƿ�����ռ�⵽��Բ�Ƿ��ظ�
						isDuplicate = 0;
						addr = 0;
						for (int i = 0; i<final_circle_num; i++)
						{
							if ( sqrt((final_circles[addr]-testCircle.x)*(final_circles[addr]-testCircle.x)+(final_circles[addr+1]-testCircle.y)*(final_circles[addr+1]-testCircle.y))<=distance_tolerance \
								&& abs(final_circles[addr+2]-testCircle.r)<=distance_tolerance )
							{
								candidates_label[validateIndex]=-1;
								isDuplicate = 1;
								//ת���ڵ㵽��i+1���Ѿ���⵽��Բ��
								for (int j = 0; j<inlier_num; j++)
								{
									gradient_map->data[inliers[j].y*gradient_map->xsize+inliers[j].x]=NOTDEF-(i+1);//���ݶ�ͼ�У���n��Բ������֧���ڵ㱻���ΪNODEF-n
								}
								break;
							}
							addr += 4;
						}
						if (!isDuplicate)
						{
							final_circle_num++;
							addr = 4*(final_circle_num-1);
							final_circles[addr]   = testCircle.x;//store the detected circle
							final_circles[addr+1] = testCircle.y;
							final_circles[addr+2] = testCircle.r;
							final_circles[addr+3] = polarity;
							candidates_label[validateIndex]=-1;//label
							//����ڵ㵽��final_circle_num���Ѿ���⵽��Բ��
							for (int j = 0; j<inlier_num; j++)
							{
								gradient_map->data[inliers[j].y*gradient_map->xsize+inliers[j].x]=NOTDEF-final_circle_num;//���ݶ�ͼ�У���n��Բ������֧���ڵ㱻���ΪNODEF-n
							}
							/*Vec3b vecB(255,0,0),vecR(0,0,255),vecG(0,255,0);
				            int X = gradient_map->xsize;
				            int Y = gradient_map->ysize;
				            Mat edge_mat = Mat::zeros(Y,X,CV_8UC3);
				            for ( int y = 0; y<Y; y++)
				              for ( int x = 0; x<X; x++)
				              {
								  edge_mat.at<Vec3b>(y,x) = (gradient_map->data[y*X+x] == NOTDEF ? 0:vecB);
				              }
				            //cv::circle(edge_mat,cv::Point(testCircle.x,testCircle.y),testCircle.r,Scalar(0,255,255));
			                for ( int i = 0; i < inlier_num; i++)
				            {
				            	edge_mat.at<Vec3b>(inliers[i].y,inliers[i].x) = vecR;
				            }
							cv::circle(edge_mat,cv::Point(circleTemp.x+0.5,circleTemp.y+0.5),circleTemp.r+0.5,Scalar(0,255,0));
							cv::circle(edge_mat,cv::Point(testCircle.x+0.5,testCircle.y+0.5),testCircle.r+0.5,Scalar(255,255,255));
			                namedWindow("w");
			                imshow("w",edge_mat);
			                waitKey();
							*/
						}
					}
				}
				else
				{
					candidates_label[validateIndex] = -1;//abandon
				}
			}
		}
	}
	(*circle_num)=final_circle_num;
	circles = (double*)malloc(sizeof(double)*final_circle_num*4);
	memcpy(circles,final_circles,sizeof(double)*final_circle_num*4);
	//free
	free(final_circles);
	free(candidates_label);
	free(inliers);
	free(new_inliers);
	free_image_double(gradient_map);//���ݶ�ͼ�У���n��Բ������֧���ڵ㱻���ΪNODEF-n.�����Ҫ�ñ��ͼ��������ڴ��޸�
}

/*
���룺
image: ��ͨ���ĻҶ�ͼ�񣬳���Ϊimage_cols �� image_rows��y��x�е�����ֵ��image[y*image_cols+x]
image_cols:�У�Ҳ����ͼ���
image_rows:�У�Ҳ����ͼ���
���:
circles: ���circle_num x 4 ��double�����ݣ�ÿһ��Բ��Ӧ��(x,y,r,polarity),Ҳ��Բ�����꣬�����꣬�뾶��Բ�ļ��ԡ�Բ���ڲ����ⲿ��������Ϊ1����֮��Ϊ-1
circle_num: ��⵽��Բ������
*/
void circleDetection(Mat gray, int image_cols, int image_rows, double T_ratio, double T_coverage, double ** circles, int * circle_num)
{
	double distance_tolerance = 2;//�̶�����
    double * out;
    int n;
	double * image;
	int X = gray.cols;
	int Y = gray.rows;
	image = (double*)malloc(X*Y*sizeof(double));
    for (int i = 0; i<Y; i++)
		for ( int j = 0; j<X; j++)
		 image[i*X+j] = (double)gray.data[i*gray.step+j]; //B����
	out = mylsd(&n,image,image_cols,image_rows,NULL,NULL,NULL);
	image_double angles;
    //calculateGradient_sobel(image,image_cols,image_rows,&angles);//sobel
	calculateGradient_canny(gray,&angles);//canny

	/*Mat edge_mat = Mat::zeros(Y,X,CV_8UC3);
	Vec3b vecW(255,255,255);
	for (int x = 0; x<X; x++)
	{
		for (int y = 0; y<Y; y++)
		{
			if ( angles->data[y*X+x] != -1024 )
				edge_mat.at<Vec3b>(y,x) = vecW;
		}
	}
	namedWindow("w2");
	imshow("w2", edge_mat);
	waitKey();

	Mat ls_mat = Mat::zeros(Y, X, CV_8UC3);
	for (int i = 0; i < n; i++)
	{
		line(ls_mat, Point(out[i * 8], out[i * 8 + 1]), Point(out[i * 8+2], out[i * 8 + 3]), Scalar(0, 255, 0));
	}
	namedWindow("w3");
	imshow("w3", ls_mat);
	waitKey();*/


    PairedSegmentList * pairseglist;
	pairseglist = getValidatePairedSegment(out,n,angles,distance_tolerance);
	if(pairseglist == NULL)
	{
	  //cout<<"��Ч�߶ζ�������"<<0<<endl;
		circles = NULL;
		*circle_num = 0;

		//before returning, it should release the memory
		if (out != NULL)
			free(out);
		if (image != NULL)
			free(image);
		free_image_double(angles);
		return;
	 }

	double * centers;
	int      centers_num;
	generateCenterCandidates(pairseglist,distance_tolerance,centers,&centers_num);
	double * candidates;
	int  candidates_num;
	generateCircleCandidates(pairseglist,centers,centers_num,distance_tolerance,candidates,&candidates_num);
	double * detected_circles;
	int detected_circle_num;
    validateCircleCandidates(angles, candidates, candidates_num, distance_tolerance,M_1_9_PI,T_ratio,T_coverage*1.0/360*M_2__PI,detected_circles,&detected_circle_num);
    (*circles) = detected_circles;
	(*circle_num) = detected_circle_num;

	if (out != NULL)
		free(out);
	freePairedSegmentList(pairseglist);

	if (centers != NULL)
		free(centers);
	if (candidates != NULL)
		free(candidates);

	if (image != NULL)
		free(image);
	free_image_double(angles);
}