#include <iostream>
#include <fstream>
#include "miscellaneous.h"
#include "lsd.h"
#include "circleDetection.h"
using namespace std;

#include "highgui.h"
#include "cv.h"
#include "cxcore.h"
#include <opencv2/opencv.hpp>  //ͷ�ļ�
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>//��ͼ��Ҫ���������ͷ�ļ�
using namespace cv;


int main()
{
  
	char* filename5 = "D://10.bmp";
	char* filename6 = "D://Graduate Design//Circle Detection//code//test820.jpg";

	int X ;  // x image size,width 
	int Y ;  // y image size,height
	double * circles = NULL;//�����ע���ͷ�
	int circle_num = 0;

	//����10000�β���
	for (int i = 0; i<10000; i++)
	{
		cout<<"iterations: "<<i<<endl;
		Mat src = imread(filename6);
		Mat src1;
		Mat gray;
		
		//resize(src,src1,Size(src.cols/5,src.rows/5));
		resize(src, src1, Size(src.cols * 2, src.rows * 2));
		cvtColor(src1,gray,CV_BGR2GRAY);
		//equalizeHist(gray,gray);


		namedWindow("w-1");
		imshow("w-1", gray);

		//GaussianBlur(gray, gray, cv::Size(5, 5), 1);

		X = gray.cols;
		Y = gray.rows;
		cout<<"w:"<<X<<" h:"<<Y<<" channels:"<<gray.channels()<<" step:"<<gray.step<<endl; 

		/*Mat mm = Mat::zeros(Y, X, CV_8UC1);
		gray.copyTo(mm);
		namedWindow("w0");
		imshow("w0", mm);*/
		//=======================================================================
		//circles�Ǻ���circleDetection�ڲ���������double���飬����Ϊcircle_num x 4��
		//���ڻ�֧���߶ε�Բ��ⷽ��
		circleDetection(gray, X, Y, 0.6, 180, &circles, &circle_num);
	    //=======================================================================

	    
		//========================================================================================================
		//print the circles that detected
		cout<<"final circles:"<<endl;
		for (int i = 0; i<circle_num; i++)
			  cout<<i<<'\t'<<circles[4*i]<<'\t'<<circles[4*i+1]<<'\t'<<circles[4*i+2]<<'\t'<<circles[4*i+3]<<endl;
		
		//draw circles
		Mat image_result;
		src1.copyTo(image_result);
		for (int i = 0; i<circle_num; i++)
		{
			cv::circle(image_result,cv::Point(circles[4*i]+0.5,circles[4*i+1]+0.5),circles[4*i+2]+0.5,Scalar(0,255,0));
		}
		//show
		namedWindow("w");
		imshow("w",image_result);
		while(waitKey(0)==-1);
		
		//=========================================================================================================

		//======================================================
		//ע���ͷ�
		if(circles != NULL)
			free(circles);
		//======================================================
	}

	//return 0;
	system("pause");
}