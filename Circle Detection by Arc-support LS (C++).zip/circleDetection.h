#ifndef _CIRCLE_DETECTION
#define _CIRCLE_DETECTION
#include "miscellaneous.h"
#include "highgui.h"
#include "cv.h"
#include "cxcore.h"
#include <opencv2/opencv.hpp>  //ͷ�ļ�
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>//��ͼ��Ҫ���������ͷ�ļ�
using namespace cv;


//ƥ���߶ζԣ��߶ζԵ�����������Բ����
typedef struct PairedSegment_s
{
	point2i pairedSegInd;
	point3d circle;
}PairedSegment;

//ƥ���߶ζԽ��
typedef struct PairedSegmentNode_s
{
	point2i pairedSegInd;
	point3d circle;
	PairedSegmentNode_s* next;
}PairedSegmentNode;

typedef struct  PairedSegmentList_s
{
	int length;
	PairedSegment * pairSeg;
}PairedSegmentList;

typedef struct Point2dNode_s
{
	point2d point;
	Point2dNode_s * next;
}Point2dNode;

typedef struct Point3dNode_s
{
	point3d point;
	Point3dNode_s * next;
}Point3dNode;

typedef struct Point1dNode_s
{
	double data;
	Point1dNode_s * next;
}Point1dNode;


/*----------------------------------------------------------------------------*/

void calculateGradient( double * img_in, unsigned int imgx, unsigned int imgy, image_double * mod, image_double * angles);
void calculateGradient_sobel( double * img_in, unsigned int imgx, unsigned int imgy, image_double * angles);
PairedSegmentList * getValidatePairedSegment( double * lines, int line_num, image_double angles, double distance_tolerance);
void  generateCenterCandidates( PairedSegmentList *pairSegmentList, double distance_tolerance, double *& centerCandidates, int * centerCandidates_num);
void  generateCircleCandidates( PairedSegmentList *pairSegmentList, double * centerCandidates, int centerCandidates_num, double distance_tolerance, double *& circleCandidates, int * circleCandidates_num);

void validateCircleCandidates(image_double angles, double * candidates, int candidate_num, double distance_tolerance, double normal_tolerance, double inlier_ratio, double angle_coverage,\
							  double *& circles, int * circle_num);
void circleDetection(Mat gray, int image_cols, int image_rows, double T_ratio, double T_coverage, double ** circles, int * circle_num);

#endif // _CIRCLE_DETECTION
