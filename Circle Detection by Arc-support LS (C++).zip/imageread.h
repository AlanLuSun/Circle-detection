#ifndef __MY_IMAGEREAD
#define __MY_IMAGEREAD
/** Read a PGM file into an double image.
    If the name is "-" the file is read from standard input.
	X: the width of image
	Y: the height of image
	the image is single channel
	the pixel (x,y) = image[y*X+x]
 */
  //image  = read_pgm_image_double(&X,&Y,"D:\\Graduate Design\\PCBͼ\\current_A.bmp");
double * read_pgm_image_double(int * X, int * Y, char * name);
/*----------------------------------------------------------------------------*/
/** Write an int image into a PGM file.
    If the name is "-" the file is written to standard output.
 */
void write_pgm_image_int(int * image, int xsize, int ysize, char * name);

#endif