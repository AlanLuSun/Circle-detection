Updated Ground Truth for
Natural Image Dataset (https://github.com/AlanLuSun/Circle-detection)

11/15/2018
Onofre Martorell
Universitat Illes Balears
o.martorell@uib.cat



There are 100 text files in "Ground Truth" folder. In each file, the data format is shown as following: 

N 
x1 y1 r1
x2 y2 r2
...
xN yN rN

N is the number of ellipses in image. xi and yi are the center coordinate and ri is the radius.

